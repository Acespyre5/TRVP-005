import { useEffect, useState } from "react"
import { fetchAllData, addTrip, addDestination } from "../requests";

import Card from "./ui/Card";
import AddTrip from "./ui/AddTrip";
import AddDestination from "./ui/AddDestination";

export default function Main() {
    const [data, setData] = useState([]);
    const [shown, setShown] = useState(false);
    const [shown3, setShown3] = useState(false);

    useEffect(() => {
        fetchAllData(setData);
    }, [])

    const sumCargos = (arr, value) => {
        return arr
          .filter(cargo => cargo.is_cargo === value)
          .reduce((sum, cargo) => sum + cargo.size, 0);
    }

    return (
        <main className="main-block">
            <div className="main-block-menu">
                {!shown && (<button className="filed-button" onClick={() => setShown(true)}>Добавить рейс</button>)}
                {!shown3 && (<button className="filed-button" onClick={() => setShown3(true)}>Добавить порт</button>)} 
            </div>
            {(shown || shown3) && (
                <div className="main-block-form">
                    {shown && (
                        <AddTrip setShown={setShown} requestFunction={addTrip} />
                    )}
                    {shown3 && (
                        <AddDestination setShown={setShown3} requestFunction={addDestination}/>
                    )}
                </div>
            )}

            <div className="main-block-cards-list">
                {data.map((element, index) => {
                    return (
                        <Card key={index} data={element} sumCargos={sumCargos} dataAll={data} setDataAll={setData}/>
                    )
                })}
            </div>
        </main>
    )
}