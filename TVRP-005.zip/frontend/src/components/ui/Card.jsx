import { useState } from "react"
import { deleteTrip, updateTrip, addCargo} from "../../requests";

import AddTrip from "./AddTrip";
import AddCargo from "./AddCargo";
import InnerCard from "./InnerCard";
import Shown from "../../images/icon-shown.png"
import Hidden from "../../images/icon-hiden.png"

export default function Card({data, sumCargos, dataAll, setDataAll}) {
    const { trip_id, destination_name, destination_id, max_cars, max_cargos, cargos, ferry_name} = data;
    const [edit, setEdit] = useState(false);
    const [shown, setShown] = useState(false);
    const [shown2, setShown2] = useState(false);
    const tripData = {
        trip_id: trip_id,
        destination_id: destination_id,
    }

    const handleDeleteTrip = async (id) => {
        if (window.confirm(`Вы уверены, что хотите удалить рейс "${destination_name} 00${trip_id}"?`)) {
            const res = await deleteTrip(id);
            if(res){
                setDataAll(dataAll.filter((element) => element.trip_id !== id));
            }
            alert(res.message);
        }
    };

    return (
        <div id={trip_id} className={`card-block`}>
            {edit?(
                <AddTrip setShown={setEdit} requestFunction={updateTrip} initialData={data}/>
            ):(
                <>
                    <div className="card-block-title">
                        <div className="card-block-title-inner">
                            <h2 className="card-block-title-name">
                                «{ferry_name}» №0-00{trip_id}
                            </h2>                           
                        </div>
                        {shown?(
                            <img className="image-button" src={Shown} alt="Свернуть" onClick={() => setShown(false)}/>
                        ):(
                            <img className="image-button" src={Hidden} alt="Подробнее" onClick={() => setShown(true)}/>
                        )}
                    </div>
                    <div className="card-block-subtitle">
                        Следует до порта «{destination_name}»
                    </div>
                    <div className="card-block-subtitle no-bg">Загруженность: {sumCargos(cargos, 1)}/{max_cargos} грузов и {sumCargos(cargos, 0)}/{max_cars} машиномест</div>
                    {shown?(
                        <div className="card-block-hidden">
                            <div className="card-block-subitems">
                                <h3>{cargos.length > 0?"Грузы":"Пока что нет грузов"}</h3>
                                {cargos.length > 0?(
                                    <div className="card-block-subitems-list">
                                        {cargos.map((element, index) => {
                                            return (
                                                <InnerCard key={index} data={element} tripData={tripData} dataAll={dataAll} setDataAll={setDataAll} sumCargos={sumCargos}/>
                                            )
                                        })}
    
                                    </div>
                                ):("")}
                            </div>
                            {shown2 ? (
                                <AddCargo setShown={setShown2} requestFunction={addCargo} dataAll={dataAll} tripData={tripData} sumCargos={sumCargos} />
                            ): (
                                <div className="buttons-block">
                                    <button className="grey-button" onClick={() => setEdit(true)}>Изменить</button>
                                    <button className="delete-button" onClick={() => handleDeleteTrip(trip_id)}>Удалить</button>
                                    {!shown2 && (<button className="filed-button" onClick={() => setShown2(true)}>Добавить груз</button>)} 
                                </div>
                            )}
                        </div>
                    ):("")}

                </>
            )}
        </div>
    )
}