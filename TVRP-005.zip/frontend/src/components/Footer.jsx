export default function Footer() {
    return <footer className="footer-block">ТРВП-005. Чернышов Павел. Все парава защищены.</footer>;
}
